import JobApplied from '~/components/JobApplied';

function JobAppliedPage() {
    return (
        <div>
            <JobApplied />
        </div>
    );
}

export default JobAppliedPage;
