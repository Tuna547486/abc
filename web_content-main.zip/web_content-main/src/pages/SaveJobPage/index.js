import SaveJob from '~/components/SaveJob';

function SaveJobPage() {
    return (
        <div>
            <SaveJob />
        </div>
    );
}

export default SaveJobPage;
