import Login from '~/components/Layout/components/Login';

function LoginPage() {
    return (
        <div>
            <Login />
        </div>
    );
}

export default LoginPage;
