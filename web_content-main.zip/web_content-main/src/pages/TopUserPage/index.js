function TopUserPage() {
    return <h2>TopUserPage page</h2>;
}

export default TopUserPage;
