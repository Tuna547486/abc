import Post from '~/components/Post';

function TableFeedPage() {
    return (
        <div>
            <Post />
            <Post />
            <Post />
            <Post />
            <Post />
            <Post />
        </div>
    );
}

export default TableFeedPage;
