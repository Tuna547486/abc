function CVPage() {
    return <h2>CVPage page</h2>;
}

export default CVPage;
