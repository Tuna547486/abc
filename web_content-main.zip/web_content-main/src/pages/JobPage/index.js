import Job from '~/components/Job';

function JobPage() {
    return (
        <div>
            <Job />
        </div>
    );
}

export default JobPage;
