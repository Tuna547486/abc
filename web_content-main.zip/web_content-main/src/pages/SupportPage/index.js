import Support from '~/components/Support';

function SupportPage() {
    return (
        <div>
            <Support />
        </div>
    );
}

export default SupportPage;
