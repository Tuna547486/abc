import PostJob from '~/components/PostJob';
import Post from '~/components/Post';

function Home() {
    return (
        <div>
            <PostJob />
            <Post />
            <Post />
            <Post />
            <Post />
            <Post />
        </div>
    );
}

export default Home;
