import Companies from '~/components/Companies';

function ListCompaniesPage() {
    return (
        <div>
            <Companies />
            <Companies />
            <Companies />
            <Companies />
            <Companies />
            <Companies />
            <Companies />
        </div>
    );
}

export default ListCompaniesPage;
